import { Component } from '@angular/core';

@Component({
  selector: 'app-profile-form',
  imports: [],
  templateUrl: './profile-form.html',
  styleUrl: './profile-form.css',
})
export class ProfileForm {

}
